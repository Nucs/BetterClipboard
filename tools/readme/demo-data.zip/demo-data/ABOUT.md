# BetterClipboard's demo data

The history, prompts and commands that the Microsoft Store listing's screenshots and the README's photos show. Load it
into a disposable claude-desktops Windows desktop with `tools/readme/seed-demo.cs` (its header has the commands); never
on a real PC: it writes the account's Claude Code, Codex and PowerShell histories.

## Where it comes from

- **The owner's own BetterClipboard history** (exported read-only on 2026-11-13): copies, Win+R commands, Notepad++
  tabs, and the prompts sent to Claude Code and Codex. Every item was read before it was kept. Kept: what is about the
  owner's open-source projects (NumSharp, OptunaSharp, BetterClipboard, Agentmaster) and plain Windows use. Left out:
  anything about other people, accounts, private projects, addresses, keys, tokens, GUIDs and session ids, private
  browsing, and every path outside those four public repositories. Two clean-ups changed text: local links into the
  NumPy submodule now point at the same files on GitHub, and HTML entities in Codex prompts are decoded.
- **Added to fill tabs** (`"generic": true` in `demo-data.json`; not the owner's history): 20 common Windows commands
  in the Run tab, 5 public documentation links, and 17 paths of real files in the four public repositories.
- **Pictures**: screenshots and documentation images of the owner's public repositories, and two crops of
  Agentmaster's own menus.

| Pictures | From | License |
|---|---|---|
| `materiallab-*`, `life-arcade-*`, `falling-sand-settled`, `numsharp-*` | [NumSharp](https://github.com/SciSharp/NumSharp): `examples/MaterialLab/docs/images`, `examples/LifeAndPong`, `examples/UnityFallingSand/docs`, `docs/website-src/images` | Apache-2.0 |
| `optunasharp-logo` | [OptunaSharp](https://github.com/SciSharp/OptunaSharp): `docs/website-src/images` | MIT |
| `agentmaster-session-menu`, `agentmaster-tab-menu` | Agentmaster's own menus, captured by the owner | AGPL-3.0 |

## What is in it

| | Count |
|---|---|
| History entries | 214 (184 texts, 30 pictures) |
| Links tab | 33 |
| Files tab (texts that are paths) | 30 |
| Images tab | 30, 11 of them screenshots saved into the Screenshots folder (the Snipping tab) |
| Run tab | 31 (11 of the owner's, 20 common commands) |
| Notepad++ tab | 15 (3 of them unsaved tabs) |
| Pinned | 2 |
| Groups | 4: NumSharp, OptunaSharp, Snippets, Releases |
| Claude tab / Codex tab | 55 / 44 prompts |
| Pwsh tab | 40 commands |

Times are relative: each item says how many minutes before "now" it was copied, run or sent, so the history always
covers the seven weeks before the moment it is loaded.

**Fewer than 30, on purpose:** Pinned (pins lead the All tab: two short ones leave the newest copies in view), Snipping
(11 screenshots), Notepad++ (the owner's other Notepad++ texts are private notes). **Empty:** Cmd (it reads open
Command Prompt windows only), Everything and ShareX (their tabs show only when those apps are installed; two of the
pictures were copied in ShareX).
